<template>
  <div class="container">
    <div class="head">
      <svg
        t="1657349406466"
        class="icon"
        viewBox="0 0 1024 1024"
        version="1.1"
        xmlns="http://www.w3.org/2000/svg"
        p-id="2261"
        width="48"
        height="48"
      >
        <path
          d="M960 512c0 97.76-28.704 185.216-85.664 263.264-56.96 78.016-130.496 131.84-220.64 161.856-10.304 1.824-18.368 0.448-22.848-4.032a22.4 22.4 0 0 1-7.2-17.504v-122.88c0-37.632-10.304-65.44-30.464-82.912a409.856 409.856 0 0 0 59.616-10.368 222.752 222.752 0 0 0 54.72-22.816c18.848-10.784 34.528-23.36 47.104-38.592 12.544-15.232 22.848-35.904 30.912-61.44 8.096-25.568 12.128-54.688 12.128-87.904 0-47.072-15.232-86.976-46.208-120.16 14.368-35.456 13.024-74.912-4.48-118.848-10.752-3.616-26.432-1.344-47.072 6.272s-38.56 16.16-53.824 25.568l-21.984 13.888c-36.32-10.304-73.536-15.232-112.096-15.232s-75.776 4.928-112.096 15.232a444.48 444.48 0 0 0-24.672-15.68c-10.336-6.272-26.464-13.888-48.896-22.432-21.952-8.96-39.008-11.232-50.24-8.064-17.024 43.936-18.368 83.424-4.032 118.848-30.496 33.632-46.176 73.536-46.176 120.608 0 33.216 4.032 62.336 12.128 87.456 8.032 25.12 18.368 45.76 30.496 61.44 12.544 15.68 28.224 28.704 47.072 39.04 18.848 10.304 37.216 17.92 54.72 22.816a409.6 409.6 0 0 0 59.648 10.368c-15.712 13.856-25.12 34.048-28.704 60.064a99.744 99.744 0 0 1-26.464 8.512 178.208 178.208 0 0 1-33.184 2.688c-13.024 0-25.568-4.032-38.144-12.544-12.544-8.512-23.296-20.64-32.256-36.32a97.472 97.472 0 0 0-28.256-30.496c-11.232-8.064-21.088-12.576-28.704-13.92l-11.648-1.792c-8.096 0-13.92 0.928-17.056 2.688-3.136 1.792-4.032 4.032-2.688 6.72s3.136 5.408 5.376 8.096 4.928 4.928 7.616 7.168l4.032 2.688c8.544 4.032 17.056 11.232 25.568 21.984 8.544 10.752 14.368 20.64 18.4 29.6l5.824 13.44c4.928 14.816 13.44 26.912 25.568 35.872 12.096 8.992 25.088 14.816 39.008 17.504 13.888 2.688 27.36 4.032 40.352 4.032s23.776-0.448 32.288-2.24l13.472-2.24c0 14.784 0 32.288 0.416 52.032 0 19.744 0.48 30.496 0.48 31.392a22.624 22.624 0 0 1-7.648 17.472c-4.928 4.48-12.992 5.824-23.296 4.032-90.144-30.048-163.68-83.84-220.64-161.888C92.256 697.216 64 609.312 64 512c0-81.152 20.192-156.064 60.096-224.672s94.176-122.88 163.232-163.232C355.936 84.192 430.816 64 512 64s156.064 20.192 224.672 60.096 122.88 94.176 163.232 163.232C939.808 355.488 960 430.848 960 512"
          fill="#000000"
          p-id="2262"
        ></path>
      </svg>
      <div class="head-title">Sign in to Github</div>
    </div>
    <div class="form">
      <div class="form-layout">
        <div class="form-msg">Username or email address</div>
        <div>
          <el-input size="small" v-model="username" />
        </div>
        <div class="pass-msg">
          <span>Password</span>
          <a href="https://github.com/password_reset">Forgot password?</a>
        </div>
        <el-input
          size="small"
          show-password
          v-model="password"
          class="self-input"
        />
        <div>
          <el-button @click="login" size="small">{{
            $t("message.login")
          }}</el-button
          >{{ loginData.token }}
        </div>
      </div>
    </div>
    <div class="help">
      <div class="help-conent">
        New to GitHub?
        <a href="https://github.com/signup?source=login">Create an account.</a>
      </div>
    </div>
    <div class="foot">
      <div class="foot-content">
        <a href="https://github.com/site/terms">Terms</a>
        <a href="https://github.com/site/privacy">Privacy</a>
        <a href="https://docs.github.com/articles/github-security/">Security</a>
        <span>Contact GitHub</span>
      </div>
    </div>
  </div>
</template>
<script>
import {loginService} from '@/service/login'
import shareStore from "@/store/index.js";

export default {
  name: "Login",
  data: function () {
    return {
      username: "",
      password: "",
      loginData: shareStore,
    };
  },
  mounted() {
    // setTimeout(() => {
    //   shareToken.token = 'sunny'
    //   console.log('修改了')
    // }, 6000)
    // setInterval(() => {
    //   console.log(this.loginData)
    // }, 4000)
  },
  methods: {
    async login() {
      // TODO: 用户信息验证
      // 网络请求拿到的
      const pathParams = 1;
      
      // 1.url里面有路径参数
      // 2.config对象中依次为
      // 2.1 params 查询参数
      // 2.2 headers 配置我们的请求头部
      // 2.3 data 部分配置我们的请求体
      // const res = await http.post(`/pet/${pathParams}`, {
      //   params: {
      //     name: 'pjw',
      //     password: 123456
      //   },
      //   data: {
      //     body: '我很庞大'
      //   }
      // });
      const res = await loginService(1, 'pjw', 'ttt', {body: '这是大成佛法'})
      if (res.data.code !== 0) {
        this.$notify({
          title: "提示",
          message: "登录失败!",
          duration: 0,
        });
        return;
      }
      this.loginData.setAction("token", res.data.code);
      // const token = 'QAZ@WSXEDCV%TGuikfijedhngiks'
      // // 放入sessionStorage
      // sessionStorage.setItem('token', token)
      // this.$notify({
      //   title: "成功",
      //   message: "您已成功登录，已成功为您跳转至控制台",
      //   type: "success",
      // });
      // // TODO: 跳转路由 一定要记住$router
      this.$router.push("/home");
      // sessionStorage.setItem('token', '1234')
    },
  },
};
</script>
<style scoped>
* {
  padding: 0;
  margin: 0;
}

html,
body,
.container {
  height: 100%;
  width: 100%;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial,
    sans-serif, "Apple Color Emoji", "Segoe UI Emoji";
}
.head,
.form,
.help,
.foot {
  display: flex;
}

.head {
  flex-direction: column;
  align-items: center;
  padding-top: 32px;
  padding-bottom: 24px;
}

.help {
  justify-content: center;
}

.help-conent {
  width: 308px;
  border: 1px solid #afb8c1;
  padding: 16px;
  margin: 16px 0;
  border-radius: 6px;
  font-size: 14px;
  text-align: center;
}

.foot {
  display: flex;
  justify-content: center;
}

.foot-content {
  width: 308px;
  display: flex;
  justify-content: space-around;
  font-size: 12px;
}

.form {
  display: flex;
  justify-content: center;
  font-size: 14px;
}
.form-layout {
  padding: 16px;
  width: 308px;
  border: 1px solid #afb8c1;
  border-radius: 6px;
  background-color: #f6f8fa;
}

.form-msg {
  margin-bottom: 8px;
}

.pass-msg {
  margin-top: 16px;
  margin-bottom: 8px;
  display: flex;
  justify-content: space-between;
}

.head-title {
  font-weight: 300;
  padding-top: 24px;
  font-size: 24px;
  letter-spacing: -0.5px;
}

.el-button {
  margin-top: 10px !important;
}
</style>



