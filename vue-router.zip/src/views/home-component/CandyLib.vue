<template>
    <div>Candylib</div>
</template>
<script>
export default {
    name: 'CandyLib'
}
</script>