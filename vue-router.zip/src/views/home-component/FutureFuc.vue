<template>
    <div>FutureFuc</div>
</template>
<script>
export default {
    name: 'FutureFuc'
}
</script>